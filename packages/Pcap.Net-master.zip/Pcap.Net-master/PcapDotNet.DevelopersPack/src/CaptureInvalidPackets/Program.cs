﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using PcapDotNet.Core;
using PcapDotNet.Core.Extensions;
using PcapDotNet.Packets;
using PcapDotNet.Packets.Ethernet;
using PcapDotNet.Packets.IpV4;
using PcapDotNet.Packets.Transport;

namespace UsingLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            // Retrieve the device list from the local machine
            IList<LivePacketDevice> allDevices = LivePacketDevice.AllLocalMachine;

            if (allDevices.Count == 0)
            {
                Console.WriteLine("No interfaces found! Make sure WinPcap is installed.");
                return;
            }

            // Print the list
            for (int i = 0; i != allDevices.Count; ++i)
            {
                LivePacketDevice device = allDevices[i];
                Console.Write((i + 1) + ". " + device.Name);
                if (device.Description != null)
                    Console.WriteLine(" (" + device.Description + ")");
                else
                    Console.WriteLine(" (No description available)");
            }

            int deviceIndex = 0;
            do
            {
                Console.WriteLine("Enter the interface number (1-" + allDevices.Count + "):");
                string deviceIndexString = Console.ReadLine();
                if (!int.TryParse(deviceIndexString, out deviceIndex) ||
                    deviceIndex < 1 || deviceIndex > allDevices.Count)
                {
                    deviceIndex = 0;
                }
            } while (deviceIndex == 0);

            // Take the selected adapter
            PacketDevice selectedDevice = allDevices[deviceIndex - 1];

            // Open the device
            using (PacketCommunicator communicator =
                selectedDevice.Open(65536,                                  // portion of the packet to capture
                // 65536 guarantees that the whole packet will be captured on all the link layers
                                    PacketDeviceOpenAttributes.Promiscuous, // promiscuous mode
                                    1000))                                  // read timeout
            {
                // Check the link layer. We support only Ethernet for simplicity.
                if (communicator.DataLink.Kind != DataLinkKind.Ethernet)
                {
                    Console.WriteLine("This program works only on Ethernet networks.");
                    return;
                }

                // Compile and set the filter
//                communicator.SetFilter("ip and tcp");

                Console.WriteLine("Listening on " + selectedDevice.Description + "...");

                // start the capture
                var query = from packet in communicator.ReceivePackets()
//                            where !packet.IsValid
                            select packet;

                using (PacketDumpFile dumpFile = communicator.OpenDump("dump.pcap"))
                {
                    foreach (Packet packet in query)
                    {
                        if (packet.Length <= 60 &&
                            packet.Ethernet.EtherType == EthernetType.IpV4 &&
                            packet.Ethernet.IpV4.Protocol == IpV4Protocol.Tcp &&
                            packet.Ethernet.IpV4.Tcp.ControlBits == (TcpControlBits.Synchronize | TcpControlBits.Acknowledgment))
                        {
                            Console.WriteLine("Captured Packet " + packet.Timestamp);
                        }
                        
//                        dumpFile.Dump(packet);
                    }
                }
            }
        }
    }
}